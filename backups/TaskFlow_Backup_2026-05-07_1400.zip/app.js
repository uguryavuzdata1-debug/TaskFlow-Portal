// --- Supabase Configuration ---
const SB_URL = 'https://ekjhhjrhfkoiklyxjfpu.supabase.co';
const SB_KEY = 'sb_publishable_hz1a48NHx7c8RPV_RYHfZg_YNvnNOdH';
const sbClient = supabase.createClient(SB_URL, SB_KEY);

// --- App State ---
let appState = {
    tickets: [],
    customers: [],
    settings: {
        personnel: ["UGUR YAVUZ", "AHMET BALTACI", "UGUR ISIKCEVAHIR"],
        sub_services: {
            S1: ["Food and Drink Menu", "Food Menu Only", "Drink Menu Only", "Dessert Menu", "Set Menu", "New Menu"],
            S2: ["Credit Card Setup", "Credit Card Replacement", "Credit Card Cancellation"],
            S3: ["Sales data has been deleted", "Data has been reset"],
            S4: ["Network Issues", "Wi-Fi Setup", "Modem Configuration", "OS Installation", "Virus Removal", "SSD Upgrade", "RAM Upgrade", "Hardware Repair", "Printing Problems", "General Maintenance"],
            S5: ["Other / Unlisted Issue"],
            S6: ["New Till Installation", "Till System Reconfiguration"]
        },
        pricing: { S1_SetMenu: 35.0, S1_Base: 125.0, S1_Hourly: 25.0, S2: 125.0, S3: 125.0, S4: 65.0, S6: 0.0 },
        sheet_url: localStorage.getItem('taskflow_gas_url') || ''
    },
    activeTab: 'dashboard',
    currentInvoiceTab: 'pending',
    currentDataTab: 'all',
    currentUser: 'UGUR YAVUZ',
    editingRecordId: null,
    alertCallback: null
};

// --- Custom Alert System ---
function showAlert(title, message, icon = '🔔', showCancel = false, isPrompt = false, callback = null) {
    document.getElementById('alert-title').innerText = title;
    document.getElementById('alert-message').innerText = message;
    document.getElementById('alert-icon').innerText = icon;
    document.getElementById('alert-input').value = '';
    if (showCancel) document.getElementById('alert-btn-cancel').classList.remove('hidden'); else document.getElementById('alert-btn-cancel').classList.add('hidden');
    if (isPrompt) document.getElementById('alert-prompt-container').classList.remove('hidden'); else document.getElementById('alert-prompt-container').classList.add('hidden');
    appState.alertCallback = callback;
    document.getElementById('alert-modal').classList.remove('hidden');
}
function closeAlert(confirm) {
    document.getElementById('alert-modal').classList.add('hidden');
    const inputVal = document.getElementById('alert-input').value;
    if (appState.alertCallback) appState.alertCallback(confirm ? (inputVal || true) : null);
    appState.alertCallback = null;
}

// --- Initialization ---
async function initApp() {
    try {
        const { data: sData } = await sbClient.from('app_settings').select('*');
        if (sData) sData.forEach(s => { if (appState.settings[s.id]) appState.settings[s.id] = s.data; });
        const { data: tData } = await sbClient.from('records').select('*').order('TIMESTAMP', { ascending: false });
        if (tData) {
            appState.tickets = tData.map(r => ({
                id: r.id, dbId: r.ID || r.db_id, crmTicket: r['CRM TICKET'] || r.crm_ticket, timestamp: r.TIMESTAMP || r.timestamp,
                company: r.COMPANY || r.company_name, companyId: r.COMPANY_ID || r.company_id, postcode: r.POSTCODE || r.postcode,
                user: r.USER || r.staff_user, mainService: r['MAIN SERVICE'] || r.service_type, subService: r['SUB SERVICE'] || r.sub_service,
                startTime: r['START TIME'] || r.start_time, endTime: r['END TIME'] || r.end_time, duration: r.DURATION || r.duration,
                price: r.PRICE || r.price, paymentStatus: r['PAYMENT STATUS'] || r.payment_status, description: r.DESCRIPTION || r.description,
                status: r.STATUS || r.status, invoiced: r.invoiced, invoiceDate: r['INV DATE'] || r.invoice_date, invoiceNo: r['INV NO'] || r.invoice_no
            }));
        }
        const { data: cData } = await sbClient.from('customers').select('*').order('COMPANY', { ascending: true });
        if (cData) appState.customers = cData;
        renderAll();
        updateStats();
    } catch (err) { console.error("Init Error:", err); }
}

// --- Navigation ---
function showTab(tabId) {
    appState.activeTab = tabId;
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
    document.getElementById(`section-${tabId}`).classList.add('active');
    document.getElementById(`btn-${tabId}`).classList.add('active');
    renderTabContent(tabId);
}

function showInvoiceTab(tabId) {
    appState.currentInvoiceTab = tabId;
    renderInvoicesTable();
}

function showDataSubTab(tabId) {
    appState.currentDataTab = tabId;
    document.querySelectorAll('#section-dataview .sub-nav-link').forEach(btn => {
        btn.style.color = '#64748b'; btn.style.opacity = '0.8'; btn.style.boxShadow = 'none';
    });
    const activeBtn = document.getElementById(`data-btn-${tabId}`);
    if (activeBtn) { activeBtn.style.color = '#111827'; activeBtn.style.opacity = '1'; activeBtn.style.boxShadow = '0 4px 6px -1px rgba(0,0,0,0.05)'; }
    renderDataTable();
}

function renderTabContent(tabId) {
    if (tabId === 'dataview') renderDataTable();
    if (tabId === 'customers') renderCustomersTable();
    if (tabId === 'invoices') renderInvoicesTable();
}

// --- Data Table Rendering ---
function renderDataTable() {
    const tbody = document.getElementById('data-table-body');
    const search = document.getElementById('dataview-search').value.toLowerCase();
    const start = document.getElementById('dataview-start-date').value;
    const end = document.getElementById('dataview-end-date').value;
    const payment = document.getElementById('dataview-payment-filter').value;
    
    let filtered = appState.tickets;
    
    // Category Filter
    if (appState.currentDataTab !== 'all') filtered = filtered.filter(t => t.mainService === appState.currentDataTab);
    
    // Payment Status Filter
    if (payment !== 'all') filtered = filtered.filter(t => t.paymentStatus === payment);
    
    // Search Filter
    if (search) filtered = filtered.filter(t => t.company.toLowerCase().includes(search) || t.dbId.toLowerCase().includes(search) || (t.description || '').toLowerCase().includes(search));
    
    // Date Range Filter
    if (start) filtered = filtered.filter(t => new Date(t.timestamp) >= new Date(start));
    if (end) { const dEnd = new Date(end); dEnd.setHours(23,59,59); filtered = filtered.filter(t => new Date(t.timestamp) <= dEnd); }

    // Summary Stats
    const totalRev = filtered.reduce((acc, t) => acc + (parseFloat(t.price) || 0), 0);
    const chargeable = filtered.filter(t => t.paymentStatus === 'Chargeable').length;
    const contract = filtered.filter(t => t.paymentStatus === 'Contract').length;
    
    document.getElementById('dv-stat-total').innerText = filtered.length;
    document.getElementById('dv-stat-revenue').innerText = `£${totalRev.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
    document.getElementById('dv-stat-split').innerText = `${chargeable} Chargeable / ${contract} Contract`;

    // Global Category Counts
    ['all', 'S1', 'S2', 'S4', 'S6'].forEach(cat => {
        const count = cat === 'all' ? appState.tickets.length : appState.tickets.filter(t => t.mainService === cat).length;
        const el = document.getElementById(`data-count-${cat}`);
        if (el) el.innerText = count;
    });

    tbody.innerHTML = filtered.map(t => `
        <tr>
            <td>${new Date(t.timestamp).toLocaleDateString()}</td>
            <td><strong style="color:var(--primary)">${t.dbId}</strong></td>
            <td title="${t.postcode}"><strong>${t.company}</strong></td>
            <td><span class="badge" style="background:#f1f5f9; color:#475569;">${t.mainService}</span></td>
            <td><span class="badge ${t.paymentStatus === 'Chargeable' ? 'badge-warning' : 'badge-success'}">${t.paymentStatus}</span></td>
            <td><strong>£${parseFloat(t.price).toFixed(2)}</strong></td>
            <td style="text-align: right;">
                <div style="display: flex; gap: 10px; justify-content: flex-end;">
                    <button class="btn-icon" onclick="showDetails('${t.id}')" title="View Details" style="background:none; border:none; cursor:pointer; font-size:1.1rem; color:#94a3b8;">👁️</button>
                    <button class="btn-icon" onclick="editInvoice('${t.id}')" title="Edit Record" style="background:none; border:none; cursor:pointer; font-size:1.1rem; color:#94a3b8;">✎</button>
                </div>
            </td>
        </tr>
    `).join('');
}

function renderCustomersTable() {
    const tbody = document.getElementById('customers-table-body');
    const search = document.getElementById('customer-search').value.toLowerCase();
    let filtered = appState.customers;
    if (search) filtered = filtered.filter(c => (c['COMPANY'] || '').toLowerCase().includes(search) || (c['CUSTOMER ID'] || '').toLowerCase().includes(search));
    tbody.innerHTML = filtered.map(c => `
        <tr>
            <td style="padding: 16px 20px;"><strong>${c['CUSTOMER ID'] || 'N/A'}</strong></td>
            <td style="padding: 16px 20px;"><strong>${c['COMPANY'] || 'N/A'}</strong></td>
            <td style="padding: 16px 20px;">${c['POSTCODE'] || '0'}</td>
            <td style="padding: 16px 20px;"><span class="badge ${c['SERVICE STATUS'] === 'Contract' ? 'badge-success' : 'badge-warning'}">${c['SERVICE STATUS'] || 'No Contract'}</span></td>
            <td style="padding: 16px 20px; text-align: right;"><button class="btn" onclick="filterByCustomer('${c['COMPANY']}')">History</button></td>
        </tr>
    `).join('');
}

function renderInvoicesTable() {
    const tbody = document.getElementById('invoice-table-body');
    const isPending = appState.currentInvoiceTab === 'pending';
    const filtered = appState.tickets.filter(t => t.paymentStatus === 'Chargeable' && (isPending ? !t.invoiced : t.invoiced));
    document.getElementById('count-pending').innerText = appState.tickets.filter(t => !t.invoiced && t.paymentStatus === 'Chargeable').length;
    document.getElementById('count-invoiced').innerText = appState.tickets.filter(t => t.invoiced && t.paymentStatus === 'Chargeable').length;
    
    // Toggle Button Styles
    const pBtn = document.getElementById('inv-btn-pending');
    const iBtn = document.getElementById('inv-btn-invoiced');
    if (isPending) { pBtn.style.color = '#1e40af'; pBtn.style.opacity = '1'; iBtn.style.color = '#64748b'; iBtn.style.opacity = '0.7'; }
    else { iBtn.style.color = '#1e40af'; iBtn.style.opacity = '1'; pBtn.style.color = '#64748b'; pBtn.style.opacity = '0.7'; }

    tbody.innerHTML = filtered.map(t => `
        <tr style="border-bottom: 1px solid #f1f5f9;">
            <td style="padding: 20px;"><div style="color:#2563eb; font-weight:700;">${t.dbId}</div><div style="color:#64748b; font-size:11px;">${new Date(t.timestamp).toLocaleDateString()}</div></td>
            <td style="padding: 20px;"><div style="font-weight:700;">${t.company}</div><div style="color:#64748b; font-size:11px;">${t.postcode}</div></td>
            <td style="padding: 20px;"><div style="font-weight:700;">${t.subService}</div><div style="color:#64748b; font-size:11px;">${t.mainService}</div></td>
            <td style="padding: 20px;"><strong>£${parseFloat(t.price).toFixed(2)}</strong></td>
            <td style="padding: 20px; text-align: right;"><div style="display: flex; align-items: center; justify-content: flex-end; gap: 12px;"><button onclick="editInvoice('${t.id}')" style="background:none; border:none; cursor:pointer; font-size:1.2rem; color:#94a3b8;">✎</button>${isPending ? `<button onclick="markAsInvoiced('${t.id}')" style="background:#111827; color:white; padding:10px 20px; border-radius:10px; border:none; font-size:11px; font-weight:700; cursor:pointer;">PROCESS</button>` : `<span class="badge badge-success">INVOICED</span>`}</div></td>
        </tr>
    `).join('');
}

// --- Modal Functions ---
function editInvoice(id) {
    const r = appState.tickets.find(t => t.id == id); if (!r) return;
    appState.editingRecordId = id;
    const content = document.getElementById('modal-details-content');
    document.getElementById('modal-title').innerText = "Edit Ticket – " + r.dbId;
    document.getElementById('btn-modal-save').classList.remove('hidden');
    
    content.innerHTML = `
        <div style="padding: 1rem;">
            <div class="grid-4">
                <div class="field"><label>Staff</label><select id="e-user">${appState.settings.personnel.map(p => `<option value="${p}" ${r.user === p ? 'selected' : ''}>${p}</option>`).join('')}</select></div>
                <div class="field"><label>Database ID</label><input type="text" id="e-db-id" value="${r.dbId}" readonly style="background:#f1f5f9;"></div>
                <div class="field"><label>CRM Ticket</label><input type="text" id="e-crm-ticket" value="${r.crmTicket || ''}"></div>
                <div class="field"><label>Timestamp</label><input type="text" id="e-timestamp" value="${new Date(r.timestamp).toLocaleString()}" readonly style="background:#f1f5f9;"></div>
            </div>
            <div class="grid-3 mt-2">
                <div class="field"><label>Customer Number</label><input type="text" id="e-company-id" value="${r.companyId || ''}"></div>
                <div class="field"><label>Company Name</label><input type="text" id="e-company" value="${r.company}"></div>
                <div class="field"><label>Postcode</label><input type="text" id="e-postcode" value="${r.postcode || ''}"></div>
            </div>
            <div class="grid-2 mt-2">
                <div class="field"><label>Category</label>
                    <select id="e-main-service" onchange="updateEditSubServices()">
                        <option value="S1" ${r.mainService === 'S1' ? 'selected' : ''}>MENU UPDATE</option>
                        <option value="S2" ${r.mainService === 'S2' ? 'selected' : ''}>CREDIT CARD</option>
                        <option value="S3" ${r.mainService === 'S3' ? 'selected' : ''}>DATA RESET</option>
                        <option value="S4" ${r.mainService === 'S4' ? 'selected' : ''}>SERVICE</option>
                        <option value="S5" ${r.mainService === 'S5' ? 'selected' : ''}>OTHER</option>
                        <option value="S6" ${r.mainService === 'S6' ? 'selected' : ''}>TILL SETUP</option>
                    </select>
                </div>
                <div class="field"><label>Sub Service</label><select id="e-sub-service"></select></div>
            </div>
            <div class="grid-3 mt-2">
                <div class="field"><label>Start Time</label><input type="time" id="e-start-time" value="${r.startTime || ''}"></div>
                <div class="field"><label>End Time</label><input type="time" id="e-end-time" value="${r.endTime || ''}"></div>
                <div class="field"><label>Duration</label><input type="text" id="e-duration" value="${r.duration || 0}" readonly style="background:#f1f5f9;"></div>
            </div>
            <div class="field mt-2"><label>Work Details</label><textarea id="e-desc" style="min-height:80px;">${r.description || ''}</textarea></div>
            <div class="mt-2"><p style="font-size:11px; font-weight:700; color:#64748b; margin-bottom:10px;">PAYMENT & BILLING</p></div>
            <div class="grid-3">
                <div class="field"><label>Mode</label>
                    <select id="e-payment">
                        <option value="Chargeable" ${r.paymentStatus === 'Chargeable' ? 'selected' : ''}>Chargeable</option>
                        <option value="Contract" ${r.paymentStatus === 'Contract' ? 'selected' : ''}>Contract</option>
                        <option value="Free" ${r.paymentStatus === 'Free' ? 'selected' : ''}>Free</option>
                    </select>
                </div>
                <div class="field"><label>Price (£)</label><input type="number" id="e-price" value="${r.price}" step="0.01"></div>
                <div class="field"><label>Invoiced</label>
                    <select id="e-invoiced">
                        <option value="false" ${!r.invoiced ? 'selected' : ''}>Pending</option>
                        <option value="true" ${r.invoiced ? 'selected' : ''}>Invoiced</option>
                    </select>
                </div>
            </div>
            <div class="grid-2 mt-2">
                <div class="field"><label>SERVICE NO</label><input type="text" id="e-inv-no" value="${r.invoiceNo || ''}" readonly style="background:#f1f5f9;"></div>
                <div class="field"><label>SERVICE DATE</label><input type="text" value="${r.invoiceDate || ''}" readonly style="background:#f1f5f9;"></div>
            </div>
        </div>
    `;
    updateEditSubServices(r.subService);
    document.getElementById('details-modal').classList.remove('hidden');
}

function updateEditSubServices(selected) {
    const main = document.getElementById('e-main-service').value;
    const opts = appState.settings.sub_services[main] || [];
    const select = document.getElementById('e-sub-service');
    select.innerHTML = opts.map(o => `<option value="${o}" ${selected === o ? 'selected' : ''}>${o}</option>`).join('');
}
async function saveRecordEdits() {
    const updates = { 
        USER: document.getElementById('e-user').value,
        "CRM TICKET": document.getElementById('e-crm-ticket').value,
        COMPANY_ID: document.getElementById('e-company-id').value,
        COMPANY: document.getElementById('e-company').value,
        POSTCODE: document.getElementById('e-postcode').value,
        "MAIN SERVICE": document.getElementById('e-main-service').value,
        "SUB SERVICE": document.getElementById('e-sub-service').value,
        "START TIME": document.getElementById('e-start-time').value,
        "END TIME": document.getElementById('e-end-time').value,
        DURATION: parseInt(document.getElementById('e-duration').value) || 0,
        DESCRIPTION: document.getElementById('e-desc').value,
        "PAYMENT STATUS": document.getElementById('e-payment').value,
        PRICE: parseFloat(document.getElementById('e-price').value) || 0,
        invoiced: document.getElementById('e-invoiced').value === 'true'
    };
    try { 
        await sbClient.from('records').update(updates).eq('id', appState.editingRecordId); 
        closeModal(); 
        initApp(); 
        showAlert('Success', 'Record updated successfully!', '✅');
    } catch (err) { showAlert('Error', err.message, '❌'); }
}
function showDetails(id) {
    const r = appState.tickets.find(t => t.id == id);
    if (!r) return;
    document.getElementById('modal-title').innerText = "Record Details Viewer";
    document.getElementById('btn-modal-save').classList.add('hidden');
    
    const detailsHtml = `
        <div style="background:#f8fafc; padding:1.5rem; border-radius:12px; border:1px solid #e2e8f0;">
            <div class="grid-2" style="gap: 20px;">
                <div>
                    <h4 style="font-size:11px; text-transform:uppercase; color:#64748b; margin-bottom:10px;">Primary Info</h4>
                    <div style="margin-bottom:8px;"><strong>ID:</strong> ${r.dbId}</div>
                    <div style="margin-bottom:8px;"><strong>Date:</strong> ${new Date(r.timestamp).toLocaleString()}</div>
                    <div style="margin-bottom:8px;"><strong>Staff:</strong> ${r.user}</div>
                    <div style="margin-bottom:8px;"><strong>CRM Ticket:</strong> ${r.crmTicket || 'N/A'}</div>
                </div>
                <div>
                    <h4 style="font-size:11px; text-transform:uppercase; color:#64748b; margin-bottom:10px;">Customer Info</h4>
                    <div style="margin-bottom:8px;"><strong>Company:</strong> ${r.company}</div>
                    <div style="margin-bottom:8px;"><strong>Postcode:</strong> ${r.postcode}</div>
                    <div style="margin-bottom:8px;"><strong>Customer ID:</strong> ${r.companyId}</div>
                </div>
            </div>
            <hr style="margin:20px 0; border:none; border-top:1px solid #e2e8f0;">
            <div class="grid-2" style="gap: 20px;">
                <div>
                    <h4 style="font-size:11px; text-transform:uppercase; color:#64748b; margin-bottom:10px;">Work Details</h4>
                    <div style="margin-bottom:8px;"><strong>Service:</strong> ${r.mainService} / ${r.subService}</div>
                    <div style="margin-bottom:8px;"><strong>Duration:</strong> ${r.duration} min</div>
                    <div style="margin-bottom:8px;"><strong>Time:</strong> ${r.startTime} - ${r.endTime}</div>
                </div>
                <div>
                    <h4 style="font-size:11px; text-transform:uppercase; color:#64748b; margin-bottom:10px;">Billing Info</h4>
                    <div style="margin-bottom:8px;"><strong>Price:</strong> £${parseFloat(r.price).toFixed(2)}</div>
                    <div style="margin-bottom:8px;"><strong>Status:</strong> ${r.paymentStatus}</div>
                    <div style="margin-bottom:8px;"><strong>Invoiced:</strong> ${r.invoiced ? '✅ Yes' : '❌ No'}</div>
                    <div style="margin-bottom:8px;"><strong>Invoice No:</strong> ${r.invoiceNo || 'N/A'}</div>
                </div>
            </div>
            <div style="margin-top:20px;">
                <h4 style="font-size:11px; text-transform:uppercase; color:#64748b; margin-bottom:10px;">Description</h4>
                <div style="background:white; padding:12px; border-radius:8px; border:1px solid #e2e8f0; min-height:60px;">${r.description || 'No description provided.'}</div>
            </div>
        </div>
    `;
    
    document.getElementById('modal-details-content').innerHTML = detailsHtml;
    document.getElementById('details-modal').classList.remove('hidden');
}
function closeModal() { document.getElementById('details-modal').classList.add('hidden'); appState.editingRecordId = null; }

// --- Dashboard Actions ---
async function handleLogin() {
    if (document.getElementById('login-remember').checked) localStorage.setItem('taskflow_remembered', 'true');
    document.body.classList.remove('is-logged-out');
    document.getElementById('login-screen').classList.add('hidden');
    document.getElementById('main-nav').classList.remove('hidden');
    document.getElementById('main-content').classList.remove('hidden');
    initApp();
}

function toggleMainForm(state) {
    ['dashboard-home', 'dashboard-category-selection', 'dashboard-form-container'].forEach(v => {
        const el = document.getElementById(v); if (el) el.style.display = 'none';
    });
    if (state === 'category') document.getElementById('dashboard-category-selection').style.display = 'block';
    else if (state === 'form') document.getElementById('dashboard-form-container').style.display = 'block';
    else document.getElementById('dashboard-home').style.display = 'block';
}

function selectCategory(cat) { resetForm(); document.getElementById('f-service-type').value = cat; updateDynamicFields(); toggleMainForm('form'); }

function updateDynamicFields() {
    const main = document.getElementById('f-service-type').value;
    const opts = appState.settings.sub_services[main] || [];
    document.getElementById('f-sub-service').innerHTML = opts.map(o => `<option value="${o}">${o}</option>`).join('');
    let extra = ''; if (main === 'S2') extra = `<div class="grid-2 mt-2"><div class="field"><label>IKA App</label><select id="f-ika-app"><option>No</option><option>Yes</option></select></div><div class="field"><label>Card Company</label><input type="text" id="f-card-company" placeholder="Dojo etc."></div></div>`;
    document.getElementById('dynamic-fields-container').innerHTML = extra + `<div class="field mt-2"><label>Work Details</label><textarea id="f-desc" style="min-height:80px;"></textarea></div>`;
    calculatePrice();
}

function calculatePrice() {
    const main = document.getElementById('f-service-type').value;
    const sub = document.getElementById('f-sub-service').value;
    const dur = parseInt(document.getElementById('f-duration').value) || 0;
    const p = appState.settings.pricing;
    let price = 0;
    if (main === 'S1') { if (sub === 'Set Menu') price = p.S1_SetMenu; else { price = p.S1_Base; if (dur > 60) price += Math.ceil((dur - 60) / 60) * p.S1_Hourly; } }
    else if (p[main]) price = p[main];
    document.getElementById('f-est-price').value = price.toFixed(2); document.getElementById('f-price').value = price.toFixed(2);
}

function calculateDuration() {
    const s = document.getElementById('f-start-time').value; const e = document.getElementById('f-end-time').value;
    if (s && e) {
        const [sh,sm] = s.split(':').map(Number); const [eh,em] = e.split(':').map(Number);
        let diff = (eh*60+em) - (sh*60+sm); if (diff < 0) diff += 1440;
        document.getElementById('f-duration').value = diff; calculatePrice();
    }
}

function resetForm() {
    const form = document.getElementById('master-form'); if (form) form.reset();
    const nextId = appState.tickets.length + 1001;
    document.getElementById('f-db-id').value = `REC-${nextId}`; document.getElementById('f-invoice-no').value = `SRV-${nextId}`;
    document.getElementById('f-timestamp').value = new Date().toLocaleString(); document.getElementById('f-invoice-date').value = new Date().toISOString().split('T')[0];
    document.getElementById('f-user').innerHTML = appState.settings.personnel.map(p => `<option value="${p}">${p}</option>`).join('');
    updateDynamicFields();
}

document.getElementById('master-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]'); btn.innerText = 'Saving...'; btn.disabled = true;
    const rec = {
        ID: document.getElementById('f-db-id').value, crm_ticket: document.getElementById('f-crm-ticket').value, service_number: document.getElementById('f-invoice-no').value,
        TIMESTAMP: new Date().toISOString(), COMPANY: document.getElementById('f-company').value, POSTCODE: document.getElementById('f-postcode').value,
        USER: document.getElementById('f-user').value, "MAIN SERVICE": document.getElementById('f-service-type').value, "SUB SERVICE": document.getElementById('f-sub-service').value,
        "START TIME": document.getElementById('f-start-time').value, "END TIME": document.getElementById('f-end-time').value, DURATION: parseInt(document.getElementById('f-duration').value),
        PRICE: parseFloat(document.getElementById('f-price').value), "PAYMENT STATUS": document.getElementById('f-payment-status').value, DESCRIPTION: document.getElementById('f-desc').value,
        STATUS: 'Logged', invoiced: false
    };
    try { await sbClient.from('records').insert([rec]); showAlert('Success', 'Record saved!', '✅'); initApp(); toggleMainForm('home'); } catch (err) { showAlert('Error', err.message, '❌'); }
    finally { btn.innerText = 'Process Transaction'; btn.disabled = false; }
});

function updateStats() {
    document.getElementById('stat-pending').innerText = appState.tickets.filter(t => t.status === 'Logged').length;
    document.getElementById('stat-completed').innerText = appState.tickets.filter(t => t.status === 'Completed').length;
    document.getElementById('stat-customers').innerText = appState.customers.length;
}

function autoFillCustomerInfo() {
    const c = appState.customers.find(x => x.COMPANY === document.getElementById('f-company').value);
    if (c) { document.getElementById('f-company-id').value = c['CUSTOMER ID'] || ''; document.getElementById('f-postcode').value = c['POSTCODE'] || ''; }
}

async function markAsInvoiced(id) {
    showAlert('Process Invoice', 'Enter Invoice Number:', '🧾', true, true, async (n) => {
        if (!n) return; try { await sbClient.from('records').update({ invoiced: true, "INV NO": n === true ? `INV-${Date.now()}` : n, "INV DATE": new Date().toISOString().split('T')[0] }).eq('id', id); initApp(); } catch (e) { showAlert('Error', e.message, '❌'); }
    });
}

function filterByCustomer(name) { showTab('dataview'); document.getElementById('dataview-search').value = name; renderDataTable(); }
function renderAll() { renderTabContent(appState.activeTab); document.getElementById('vtiger-customer-list').innerHTML = appState.customers.map(c => `<option value="${c.COMPANY}">`).join(''); }
document.addEventListener('DOMContentLoaded', () => { if (localStorage.getItem('taskflow_remembered') === 'true') handleLogin(); });

window.handleLogin = handleLogin; window.showTab = showTab; window.showInvoiceTab = showInvoiceTab; window.showDataSubTab = showDataSubTab; window.toggleMainForm = toggleMainForm;
window.selectCategory = selectCategory; window.updateDynamicFields = updateDynamicFields; window.calculateDuration = calculateDuration; window.calculatePrice = calculatePrice;
window.resetForm = resetForm; window.autoFillCustomerInfo = autoFillCustomerInfo; window.renderDataTable = renderDataTable; window.renderCustomersTable = renderCustomersTable;
window.renderInvoicesTable = renderInvoicesTable; window.editInvoice = editInvoice; window.saveRecordEdits = saveRecordEdits; window.showDetails = showDetails;
window.closeModal = closeModal; window.markAsInvoiced = markAsInvoiced; window.showAlert = showAlert; window.closeAlert = closeAlert; window.filterByCustomer = filterByCustomer;
